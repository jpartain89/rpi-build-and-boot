The examples in this folder belong to the shaders tutorial in the openFrameworks web page: http://openframeworks.cc/tutorials/graphics/shaders.html
